/*
 Programmer: Ash Corcoran
 Date: 8/24/21
 Program:  Hello Worlds part 1  
 Filename: HW1.cpp
 Description: This program prints "Hello World"
 Assistance received from: "C++ Programming: Program Design Including Data Structures" by D.S. Malik, Chapter 2, Pg. 29 for basic C++ syntax and headers
 Name of input file: N/A
 How to compile:  g++ -o HW1 HW1.cpp
 How to execute: ./HW1
*/

#include <iostream>
using namespace std;

int main() {
//used tutorialspoint for cout <<
 cout << "Hello World\n";
return 0;
}

